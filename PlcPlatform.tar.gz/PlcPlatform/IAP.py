# -*- coding: utf-8 -*-
import os
import sys
import time


def start():
    print("")
    print("")
    print("-------------------------------------------------")
    print("")
    print("Welcome to Industrial Attack Platform")
    print("")
    print("-------------------------------------------------")
    print("")
    print("")


def plcinject(self):
    print("1 plcInjectPayload")
    print("2 plcModbusDownload")
    print("3 plcModbusHandler")
    inputpy = input("seclection:")
    if str(inputpy) == str("plcInjectPayload") or str(inputpy) == str("1"):
        os.system("python2 plcInjectPayload.py")
    elif str(inputpy) == str("plcInjectPayload") or str(inputpy) == str("2"):
        os.system("python2 plcModbusDownload.py")
    elif str(inputpy) == str("plcModbusHandler") or str(inputpy) == str("3"):
        os.system("python2 plcModbusHandler.py")
    else:
        print('try again')
        return

def plcs(self):

    while True:
        try:
            print("    ")
            print("    ")
            print("Seclect plc type:")
            print("1 Siemens")
            print("2 Schneider")
            #print("3 qnx")
            inputplcs = input("Seclection:")
            if str(inputplcs) == str("Siemens") or str(inputplcs) == str("1"):
                while True:
                      try:
                          print("    ")
                          print("    ")    
                          print("Seclect siemens type")  
                          print("1 s7_300_400")
                          print("2 s7_1200_plc")
                          inputsiemens = input("Seclection:")
                          if str(inputsiemens) == str("s7_300_400") or str(inputsiemens) == str("1"):
                             while True:
                                    try:
                                        ip       = input("Target address e.g. 192.168.1.1:")
                                        port     = int(input("Target Port e.g. 102:"))
                                        slot     = int(input("CPU slot number e.g. 2:"))
                                        command  = int(input("command 1:start plc, 2:stop plc:"))
                                        os_s7300 = 'python3 ./plcs/siemens/s7_300_400.py %s %d %d %d' % (ip,port,slot,command)
                                        res      = os.system(os_s7300)
                                    except KeyboardInterrupt:
                                        break

                          elif str(inputsiemens) == str("s7_1200_plc") or str(inputsiemens) == str("2"):
                              while True:
                                     try:
                                         ip       = input("Target address e.g. 192.168.1.1:")
                                         port     = int(input("Target Port e.g. 102:"))
                                         slot     = int(input("CPU slot number e.g. 2:"))
                                         command  = int(input("command 1:start plc, 2:stop plc,3:reset plc and ip:"))
                                         os_s71200 = 'python3 ./plcs/siemens/s7_1200_plc.py %s %d %d %d' % (ip,port,slot,command)
                                         res = os.system(os_s71200)
                                         print(res)
                                     except KeyboardInterrupt:
                                         break
                      except KeyboardInterrupt:
                             break
            elif str(inputplcs) == str("Schneider") or str(inputplcs) == str("2"):
                 print("    ")
                 print("    ")    
                 print("Seclect Schneider type")  
                 print("1 quantum_140")
                 inputschneider = input("Seclection:")
                 if str(inputschneider) == str("quantum_140") or str(inputschneider) == str("1"):
                    while True:
                        try:
                            ip       = input("Target address e.g. 192.168.1.1:")
                            port     = int(input("Target Port e.g. 102:"))
                            command  = int(input("command 1:start plc, 2:stop plc:"))
                            os_q140  = 'python3 ./plcs/schneider/quantum_140.py %s %d %d' % (ip,port,command)
                            res      = os.system(os_q140)
                        except KeyboardInterrupt:
                             break           
        except KeyboardInterrupt:
            break


def sniff(self):
         hostIP   = str(input("hostIP e.g. 172.0.1.1:"))
         Dstport  = int(input("Dstport e.g. 80:"))
         Countnum = int(input("Countnum e.g. -1:"))
         os_sniff = 'python3 ./sniff/sniff.py %s %d %d' % (hostIP,Dstport,Countnum)
         res = os.system(os_sniff)
         print(res)


def nmap(self):
         input_target = str(input("target e.g. 192.168.1.1:"))
         print(input_target)
         input_port = str(input("port e.g.80:"))
         os_str = 'python3 ./nmap/plcnmap.py %s %s' % (input_target, input_port)
         res = os.system(os_str)
         print(res)
            

def arp(self):
         input_target = input("target e.g. 192.168.1.1:")
         input_ip = input("ip e.g. 192.168.1.1:")
         os_arp = 'python3 ./arp/arp.py %s %s' % (input_target, input_ip)
         res = os.system(os_arp)
         print(res)    
           
           
                   
def selectpy(self):
    try:
        if str(self) == str('arp') or str(self) == str("1"):
            arp(self)
        elif str(self) == str('nmap') or str(self) == str("2"):
            nmap(self)
        elif str(self) == str('sniff') or str(self) == str("3"):
            sniff(self)
        #elif str(self) == str('plcinject') or str(self) == str("4"):
         #   plcinject(self)
        elif str(self) == str('plcs') or str(self) == str("4"):
            plcs(self)
        else:
            print('try again')
    except KeyboardInterrupt:
        return


def main():
   while True:
         print("    ")
         print("    ")
         print("Selcet the function you want:")
         print("1.Arp")
         print("2.Nmap")
         print("3.Sniff")
         #print("4.plcinject")
         print("4.Plcs")
         input_data = input("Select your options:")
         selectpy(input_data)


if __name__ == '__main__':
    start()
    main()




