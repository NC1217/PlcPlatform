import threading
import tkinter as tk
from tkinter import *
import os
import subprocess




class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.running = False
        self.title("iap")
        self.geometry("900x600")

        # 创建9个Frame
        self.frame0 = tk.Frame(self, height=600, width=900)
        self.frame1 = tk.Frame(self, height=600, width=900)
        self.frame2 = tk.Frame(self, height=600, width=900)
        self.frame3 = tk.Frame(self, height=600, width=900)
        self.frame4 = tk.Frame(self, height=600, width=900)
        self.frame5 = tk.Frame(self, height=600, width=900)
        self.frame6 = tk.Frame(self, height=600, width=900)
        self.frame7 = tk.Frame(self, height=600, width=900)
        self.frame8 = tk.Frame(self, height=600, width=900)
        self.frame9 = tk.Frame(self, height=600, width=900)

        # 在Frame0中添加控件
        self.frame0.pack_propagate(0)
        tk.Label(self.frame0, text="IAP", width=4, height=3).place(relx=0.45, rely=0.08)
        tk.Button(self.frame0, text="Arp欺骗", command=self.show_frame1).place(relx=0.15, rely=0.5)
        tk.Button(self.frame0, text="Nmap扫描", command=self.show_frame2).place(relx=0.35, rely=0.5)
        tk.Button(self.frame0, text="sniff嗅探", command=self.show_frame3).place(relx=0.55, rely=0.5)
        tk.Button(self.frame0, text="PLC类型", command=self.show_frame4).place(relx=0.75, rely=0.5)

        # 在Frame1中添加控件
        self.frame1.pack_propagate(0)
        tk.Label(self.frame1, text="Arp欺骗").place(relx=0.45, rely=0.08)
        tk.Label(self.frame1, text='请输入目标IP').place(relx=0.2, rely=0.4)
        F1E0 = StringVar()
        self.laF1E0 = tk.Entry(self.frame1, textvariable=F1E0)
        self.laF1E0.place(relx=0.3, rely=0.4)
        F1E0.set('192.168.1.1')
        tk.Label(self.frame1, text='请输入源IP').place(relx=0.2, rely=0.5)
        F1E1 = StringVar()
        self.laF1E1 = tk.Entry(self.frame1, textvariable=F1E1)
        self.laF1E1.place(relx=0.3, rely=0.5)
        F1E1.set('192.168.1.1')
        tk.Button(self.frame1, text="返回首页", command=self.show_frame0).place(relx=0.8, rely=0.18)
        tk.Button(self.frame1, text="确认输入", command=self.start).place(relx=0.6, rely=0.45)
        tk.Button(self.frame1, text="终止运行",command=self.stop).place(relx=0.6, rely=0.55)


        # 在Frame2中添加控件
        self.frame2.pack_propagate(0)
        tk.Label(self.frame2, text="Nmap扫描").place(relx=0.45, rely=0.08)
        tk.Label(self.frame2, text='请输入目标IP').place(relx=0.2, rely=0.4)
        F2E0 = StringVar()
        self.laF2E0 = tk.Entry(self.frame2, textvariable=F2E0)
        self.laF2E0.place(relx=0.3, rely=0.4)
        F2E0.set('192.168.1.1')
        tk.Label(self.frame2, text='请输入目标端口').place(relx=0.2, rely=0.5)
        F2E1 = StringVar()
        self.laF2E1 = tk.Entry(self.frame2, textvariable=F2E1)
        self.laF2E1.place(relx=0.3, rely=0.5)
        F2E1.set('80')
        tk.Button(self.frame2, text="返回首页", command=self.show_frame0).place(relx=0.8, rely=0.18)
        tk.Button(self.frame2, text="确认输入", command=self.nmap).place(relx=0.6, rely=0.45)

        # 在Frame3中添加控件
        self.frame3.pack_propagate(0)
        tk.Label(self.frame3, text="sniff嗅探").place(relx=0.45, rely=0.08)
        tk.Label(self.frame3, text='请输入目标IP').place(relx=0.2, rely=0.4)
        F3E0 = StringVar()
        self.laF3E0 = tk.Entry(self.frame3, textvariable=F3E0)
        self.laF3E0.place(relx=0.3, rely=0.4)
        F3E0.set("192.168.1.1")
        tk.Label(self.frame3, text='请输入目标端口').place(relx=0.2, rely=0.5)
        F3E1 = StringVar()
        self.laF3E1 = tk.Entry(self.frame3, textvariable=F3E1)
        self.laF3E1.place(relx=0.3, rely=0.5)
        F3E1.set("80")
        F3E2 = StringVar()
        tk.Label(self.frame3, text='请输入嗅探数量').place(relx=0.2, rely=0.6)
        self.laF3E2 = tk.Entry(self.frame3, textvariable=F3E2)
        self.laF3E2.place(relx=0.3, rely=0.6)
        F3E2.set("-1")
        tk.Button(self.frame3, text="返回首页", command=self.show_frame0).place(relx=0.8, rely=0.18)
        tk.Button(self.frame3, text="确认输入", command=self.sniff).place(relx=0.6, rely=0.45)

        # 在Frame4中添加控件
        self.frame4.pack_propagate(0)
        tk.Label(self.frame4, text="PLC类型").place(relx=0.45, rely=0.08)
        tk.Button(self.frame4, text="西门子", command=self.show_frame5).place(relx=0.35, rely=0.45)
        tk.Button(self.frame4, text="施耐德", command=self.show_frame6).place(relx=0.55, rely=0.45)
        tk.Button(self.frame4, text="返回首页", command=self.show_frame0).place(relx=0.8, rely=0.18)

        # 在Frame5中添加控件
        self.frame5.pack_propagate(0)
        tk.Label(self.frame5, text="西门子").place(relx=0.45, rely=0.08)
        tk.Button(self.frame5, text="S7_300_400", command=self.show_frame7).place(relx=0.35, rely=0.45)
        tk.Button(self.frame5, text="S7_1200", command=self.show_frame8).place(relx=0.55, rely=0.45)
        tk.Button(self.frame5, text="返回上一级", command=self.show_frame4).place(relx=0.8, rely=0.18)

        # 在Frame6中添加控件
        self.frame6.pack_propagate(0)
        tk.Label(self.frame6, text="施耐德").place(relx=0.45, rely=0.08)
        tk.Button(self.frame6, text="quantum_140", command=self.show_frame9).place(relx=0.45, rely=0.45)
        tk.Button(self.frame6, text="返回上一级", command=self.show_frame4).place(relx=0.8, rely=0.18)

        # 在Frame7中添加控件
        self.frame7.pack_propagate(0)
        tk.Label(self.frame7, text="S7_300_400").place(relx=0.45, rely=0.08)
        tk.Label(self.frame7, text='请输入目标Ip').place(relx=0.2, rely=0.4)
        F7E1 = StringVar()
        self.laF7E1 = tk.Entry(self.frame7, textvariable=F7E1)
        self.laF7E1.place(relx=0.3, rely=0.4)
        F7E1.set("192.168.1.1")
        tk.Label(self.frame7, text='请输入目标端口').place(relx=0.2, rely=0.5)
        F7E2 = StringVar()
        self.laF7E2 = tk.Entry(self.frame7, textvariable=F7E2)
        self.laF7E2.place(relx=0.3, rely=0.5)
        F7E2.set("80")
        tk.Label(self.frame7, text='请输入CPU slot').place(relx=0.2, rely=0.6)
        F7E3 = StringVar()
        self.laF7E3 = tk.Entry(self.frame7, textvariable=F7E3)
        self.laF7E3.place(relx=0.3, rely=0.6)
        F7E3.set("0")
        tk.Label(self.frame7, text='请输入PLC指令').place(relx=0.2, rely=0.7)
        F7E4 = StringVar()
        self.laF7E4 = tk.Entry(self.frame7, textvariable=F7E4)
        self.laF7E4.place(relx=0.3, rely=0.7)
        F7E4.set("1")
        tk.Button(self.frame7, text="确认输入", command=self.s7300).place(relx=0.6, rely=0.45)
        tk.Button(self.frame7, text="返回上一级", command=self.show_frame5).place(relx=0.8, rely=0.18)

        # 在Frame8中添加控件
        self.frame8.pack_propagate(0)
        tk.Label(self.frame8, text="S7_1200").place(relx=0.45, rely=0.08)
        tk.Label(self.frame8, text='请输入目标Ip').place(relx=0.2, rely=0.4)
        F8E1 = StringVar()
        self.laF8E1 = tk.Entry(self.frame8, textvariable=F8E1)
        self.laF8E1.place(relx=0.3, rely=0.4)
        F8E1.set("192.168.1.1")
        tk.Label(self.frame8, text='请输入目标端口').place(relx=0.2, rely=0.5)
        F8E2 = StringVar()
        self.laF8E2 = tk.Entry(self.frame8, textvariable=F8E2)
        self.laF8E2.place(relx=0.3, rely=0.5)
        F8E2.set("80")
        tk.Label(self.frame8, text='请输入CPU slot').place(relx=0.2, rely=0.6)
        F8E3 = StringVar()
        self.laF8E3 = tk.Entry(self.frame8, textvariable=F8E3)
        self.laF8E3.place(relx=0.3, rely=0.6)
        F8E3.set("0")
        tk.Label(self.frame8, text='请输入PLC指令').place(relx=0.2, rely=0.7)
        F8E4 = StringVar()
        self.laF8E4 = tk.Entry(self.frame8, textvariable=F8E4)
        self.laF8E4.place(relx=0.3, rely=0.7)
        F8E4.set("1")
        tk.Button(self.frame8, text="确认输入", command=self.s71200).place(relx=0.6, rely=0.45)
        tk.Button(self.frame8, text="返回上一级", command=self.show_frame5).place(relx=0.8, rely=0.18)

        # 在Frame9中添加控件
        self.frame9.pack_propagate(0)
        tk.Label(self.frame9, text="quantum_140").place(relx=0.45, rely=0.08)
        tk.Label(self.frame9, text='请输入目标Ip').place(relx=0.2, rely=0.4)
        F9E1 = StringVar()
        self.laF9E1 = tk.Entry(self.frame9, textvariable=F9E1)
        self.laF9E1.place(relx=0.3, rely=0.4)
        F9E1.set("192.168.1.1")
        tk.Label(self.frame9, text='请输入目标端口').place(relx=0.2, rely=0.5)
        F9E2 = StringVar()
        self.laF9E2 = tk.Entry(self.frame9, textvariable=F9E2)
        self.laF9E2.place(relx=0.3, rely=0.5)
        F9E2.set("80")
        tk.Label(self.frame9, text='请输入PLC指令').place(relx=0.2, rely=0.6)
        F9E3 = StringVar()
        self.laF9E3 = tk.Entry(self.frame9, textvariable=F9E3)
        self.laF9E3.place(relx=0.3, rely=0.6)
        F9E3.set("1")
        tk.Button(self.frame9, text="确认输入", command=self.q140).place(relx=0.6, rely=0.45)
        tk.Button(self.frame9, text="返回上一级", command=self.show_frame6).place(relx=0.8, rely=0.18)

        # 显示第一个界面
        self.show_frame0()

    def show_frame0(self):
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame0.grid()  # 显示第一个界面

    def show_frame1(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第四个界面
        self.frame6.grid_forget()  # 隐藏第四个界面
        self.frame7.grid_forget()  # 隐藏第四个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame1.grid()  # 显示第一个界面

    def show_frame2(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame2.grid()  # 显示第二个界面

    def show_frame3(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame3.grid()  # 显示第三个界面

    def show_frame4(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame4.grid()  # 显示第四个界面

    def show_frame5(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame5.grid()  # 显示第五个界面

    def show_frame6(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame6.grid()  # 显示第六个界面

    def show_frame7(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame7.grid()  # 显示第七个界面

    def show_frame8(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame9.grid_forget()  # 隐藏第九个界面
        self.frame8.grid()  # 显示第八个界面

    def show_frame9(self):
        self.frame0.grid_forget()  # 隐藏第零个界面
        self.frame1.grid_forget()  # 隐藏第一个界面
        self.frame2.grid_forget()  # 隐藏第二个界面
        self.frame3.grid_forget()  # 隐藏第三个界面
        self.frame4.grid_forget()  # 隐藏第四个界面
        self.frame5.grid_forget()  # 隐藏第五个界面
        self.frame6.grid_forget()  # 隐藏第六个界面
        self.frame7.grid_forget()  # 隐藏第七个界面
        self.frame8.grid_forget()  # 隐藏第八个界面
        self.frame9.grid()  # 显示第九个界面

    def start(self):
        self.running = True
        t=threading.Thread(target=self.arp)
        t.start()
    def stop(self):
        self.running = False
        


    def arp(self):

        try :
              input_target = self.laF1E0.get()
              input_ip = self.laF1E1.get()
              os_arp       = 'python3 ./arp/arp.py %s %s' % (input_target, input_ip)
              res          = subprocess.Popen('python3 ./arp/arp.py %s %s' % (input_target, input_ip),shell=True)
              tk.Message(self.frame1, text='%s' % res, width=600).place(relx=0.2, rely=0.8)
        except self.running==False:
              res.kill
                 

    def nmap(self):
        input_target = self.laF2E0.get()
        input_port = self.laF2E1.get()
        os_str = 'python3 ./nmap/plcnmap.py %s %s' % (input_target, input_port)
        res    = subprocess.Popen(os_str,shell=True)
        # print(res)
        mes = tk.Message(self.frame2, res, width=200).place(relx=0.45, rely=0.8)

    def sniff(self):
        hostIP = self.laF3E0.get()
        Dstport = int(self.laF3E1.get())
        Countnum = int(self.laF3E2.get())
        os_sniff = 'python3 ./sniff/sniff.py %s %d %d' % (hostIP, Dstport, Countnum)
        res = os.system(os_sniff)
        mes = tk.Message(self.frame3, text='%s' % res, width=200).place(relx=0.45, rely=0.8)

    def s7300(self):
        ip = self.laF7E1.get()
        port = int(self.laF7E2.get())
        slot = int(self.laF7E3.get())
        command = int(self.laF7E4.get())
        os_s7300 = 'python3 ./plcs/siemens/s7_300_400.py %s %d %d %d' % (ip, port, slot, command)
        res = os.popen(os_s7300).read()
        mes = tk.Message(self.frame7, text='%s' % res, width=200).place(relx=0.45, rely=0.8)

    def s71200(self):
        ip = self.laF8E1.get()
        port = int(self.laF8E2.get())
        slot = int(self.laF8E3.get())
        command = int(self.laF8E4.get())
        os_s71200 = 'python3 ./plcs/siemens/s7_1200_plc.py %s %d %d %d' % (ip, port, slot, command)
        res = os.popen(os_s71200).read()
        mes = tk.Message(self.frame8, text='%s' % res, width=200).place(relx=0.45, rely=0.8)

    def q140(self):
        ip = self.laF9E1.get()
        port = int(self.laF9E2.get())
        command = int(self.laF9E3.get())
        os_q140 = 'python3 ./plcs/schneider/quantum_140.py %s %d %d' % (ip, port, command)
        res = os.popen(os_q140).read()
        mes = tk.Message(self.frame9, text='%s' % res, width=200).place(relx=0.45, rely=0.8)


if __name__ == "__main__":
    app = App()
    app.mainloop()
