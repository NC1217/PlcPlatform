# -*- coding: utf-8 -*-
import sys
import nmap                       #导入模块
nm = nmap.PortScanner()           #导入函数
if len(sys.argv) == 3:
    target = sys.argv[1]
    port = sys.argv[2]
    #argument = sys.argv[3]  #参数

else:
	#若用户没有输入命令行参数，则提示用户
	print("Invalid amount of arguments.")
	print("example:python3 scanner.py <ip or hostname> <port eg:22 or 1-1000>")
	sys.exit()

nm.scan(target,port) #输入你要扫描的ip与端口
for host in nm.all_hosts():       #返回被扫描的主机列表给host
    print('---------------------------------------------------------')
    print('Host : %s (%s)' % (host,nm[host].hostname()))    #nm[host].hostname()获取目标主机的主机名
    print('State : %s' % nm[host].state())                  #nm[host].state()获取主机的状态  |up|down|unknow|skipped|
    for proto in nm[host].all_protocols():                  #nm[host].all_protocols获取执行的协议['tcp','udp']
        print('-----------------------------------------------------')
        print('protocol : %s' % proto )                     #输出执行的协议
        lport = nm[host][proto].keys()                      #获取目标主机所开放的端口赋值给lport
        # lport.sort()
        for port in lport:                                                                  #将lport赋值给port并遍历
            print('port : %s\tstate : %s\tservices : %s\tversion: %s' % (port,nm[host][proto][port]['state'],nm[host][proto][port]['name'],nm[host][proto][port]['version']))  #输出扫描结果
            #print('port : %s\tstate : %s\t' % (port, nm[host][proto][port] ))  输出port相关所有结果

