from scapy.all import *
def snif(hostIP, Dstport, Countnum):
    try: 
        packet = sniff(filter='src host %s && dst port %d' %(hostIP,Dstport), count=Countnum) # 捕获四个包
        print(packet.show())
        wrpcap('data.pcap', packet)  # 保存为pcap文件
    except KeyboardInterrupt:
        return
if __name__ == '__main__':
    hostIP   = str(sys.argv[1].strip())
    Dstport  = int(sys.argv[2].strip())
    Countnum = int(sys.argv[3].strip())
    snif(hostIP,Dstport,Countnum)
